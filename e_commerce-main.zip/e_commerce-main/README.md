# E-commerce

Flutter E-commerce Application.

## Getting Started

The video description about Jerusalem App. https://odysee.com/@Mohamed_Raed:2/jerusalem:d ||
YouTube: https://www.youtube.com/watch?v=2xU7_vd9hDw

The use statemanagment : GetX. || 
dark and light mode. || 
multi language(Arabic - English - France). || 
Login( Google - Facebook ). || 
Handler API (Dio package). || 
use Get Storage save data in mobile data. || 
Location in current location.
